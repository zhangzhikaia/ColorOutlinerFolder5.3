// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "FSOItemLabelColumnReplace.h"

#include "ActorFolderTreeItem.h"
#include "ColorOutlinerUtils.h"
#include "SceneOutlinerItemLabelColumn.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/SOverlay.h"
#include "Engine/GameViewportClient.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Images/SImage.h"
#include "Styling/AppStyle.h"
#include "Editor.h"
#include "ScopedTransaction.h"
#include "SceneOutlinerStandaloneTypes.h"
#include "ISceneOutlinerMode.h"
#include "SceneOutlinerDragDrop.h"
#include "Widgets/Views/SListView.h"
#include "SortHelper.h"
#include "Widgets/SToolTip.h"
#include "ColorOutlinerUtils.h"

#define LOCTEXT_NAMESPACE "FSOItemLabelColumnReplace"

FName FSOItemLabelColumnReplace::GetColumnID()
{
	return GetID();
}

SHeaderRow::FColumn::FArguments FSOItemLabelColumnReplace::ConstructHeaderRowColumn()
{
	return SHeaderRow::Column(GetColumnID())
		.FillWidth( 5.0f );
}

const TSharedRef<SWidget> FSOItemLabelColumnReplace::ConstructRowWidget(FSceneOutlinerTreeItemRef TreeItem,
	const STableRow<FSceneOutlinerTreeItemPtr>& Row)
{
	TSharedPtr<SWidget> ItemLableRowWidget;
	
	ISceneOutliner* Outliner = WeakSceneOutliner.Pin().Get();
	check(Outliner);
	
	ItemLableRowWidget = TreeItem->GenerateLabelWidget(*Outliner, Row);

	/*start set color*/
	if(FActorFolderTreeItem* SelectedFolder = TreeItem->CastTo<FActorFolderTreeItem>())
	{
		using namespace SceneOutlinerFolderUtils;
		
		const FString FullPath = GetFolderFullPath(SelectedFolder);
		
		const TOptional<FLinearColor> PathColor = GetIsTempMap()?
				GetFolderColorTemp(SelectedFolder->GetPath().ToString()) : GetFolderColor(FullPath);
	
		if(PathColor.IsSet())
		{
			if(PathColor.GetValue() != GetOutlinerFolderDefaultColor())
			{
				SetRowWidgetColor(ItemLableRowWidget,PathColor.GetValue());
			}
		}
	}
	/*set color done*/
	
	return ItemLableRowWidget.ToSharedRef();
}

void FSOItemLabelColumnReplace::PopulateSearchStrings( const ISceneOutlinerTreeItem& Item, TArray< FString >& OutSearchStrings ) const
{
	OutSearchStrings.Add(Item.GetDisplayString());
}

void FSOItemLabelColumnReplace::SortItems(TArray<FSceneOutlinerTreeItemPtr>& OutItems, const EColumnSortMode::Type SortMode) const
{
	typedef FSceneOutlinerSortHelper<int32, SceneOutliner::FNumericStringWrapper> FSort;

	FSort()
		.Primary([this](const ISceneOutlinerTreeItem& Item){ return WeakSceneOutliner.Pin()->GetTypeSortPriority(Item); },			SortMode)
		.Secondary([](const ISceneOutlinerTreeItem& Item){ return SceneOutliner::FNumericStringWrapper(Item.GetDisplayString()); }, SortMode)
		.Sort(OutItems);
}

#undef LOCTEXT_NAMESPACE
