// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "ColorOutliner.h"

#include "LevelEditor.h"
#include "SceneOutlinerModule.h"
#include "ColorOutlinerUtils.h"
#include "SceneOutlinerMenuContext.h"
#include "SSceneOutliner.h"
#include "ToolMenu.h"
#include "ToolMenuDelegates.h"
#include "ToolMenuEntry.h"
#include "ToolMenuSection.h"
#include "ToolMenus.h"
#include "Widgets/Colors/SColorPicker.h"
#include "ActorFolderTreeItem.h"
#include "FSOItemLabelColumnReplace.h"
#include "SOutlinerTreeView.h"
#include "SceneOutlinerItemLabelColumn.h"
#include "Editor.h"
#include "EditorActorFolders.h"

#define LOCTEXT_NAMESPACE "FColorOutlinerModule"

void FColorOutlinerModule::StartupModule()
{
	RegisterOnMapRename();
	RegisterOnMapDeleted();
	RegisterOnMapChanged();
	RegisterOnFolderOperate();
	RegisterOutlinerItemLabelColumn();
	RegisterOutlinerContextMenuExtend();
}

void FColorOutlinerModule::ShutdownModule()
{
	/*UnregisterOnMapRename*/
	if(OnPreWorldRenameHandle.IsValid()){FWorldDelegates::OnPreWorldRename.Remove(OnPreWorldRenameHandle);}
	if(OnPostWorldRenameHandle.IsValid()){FWorldDelegates::OnPostWorldRename.Remove(OnPostWorldRenameHandle);}
	
	/*UnregisterOnMapDeleted*/
	if(OnAssetsPreDeleteHandle.IsValid()){FEditorDelegates::OnAssetsPreDelete.Remove(OnAssetsPreDeleteHandle);}
	if(OnAssetsDeletedHandle.IsValid()){FEditorDelegates::OnAssetsDeleted.Remove(OnAssetsDeletedHandle);}
	
	/*UnregisterOnMapChanged*/
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	if(OnMapChangedHandle.IsValid()){LevelEditorModule.OnMapChanged().Remove(OnMapChangedHandle);}
	
	/*UnregisterOnFolderOperate*/
	if(OnFolderMovedHandle.IsValid()){FActorFolders::OnFolderMoved.Remove(OnFolderMovedHandle);}
	if(OnFolderDeletedHandle.IsValid()){FActorFolders::OnFolderDeleted.Remove(OnFolderDeletedHandle);}
	
	/*UnregisterOutlinerItemLabelColumn*/
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(TEXT("SceneOutliner"));
	SceneOutlinerModule.UnRegisterColumnType<FSOItemLabelColumnReplace>();
}

void FColorOutlinerModule::RegisterOnMapRename()
{
	OnPreWorldRenameHandle = FWorldDelegates::OnPreWorldRename.AddLambda([](UWorld* World, const TCHAR* InName, UObject* NewOuter, ERenameFlags Flags, bool& bShouldFailRename)
	{
		SceneOutlinerFolderUtils::SaveMapOldName(World);
	});

	OnPostWorldRenameHandle = FWorldDelegates::OnPostWorldRename.AddLambda([](UWorld* World)
	{
		SceneOutlinerFolderUtils::OnWorldPathPostChanged(World);
	});
}

void FColorOutlinerModule::RegisterOnMapDeleted()
{
	OnAssetsPreDeleteHandle = FEditorDelegates::OnAssetsPreDelete.AddLambda([](const TArray<UObject*>& Objects)
	{
		SceneOutlinerFolderUtils::SavePathPreDelete(Objects);
	});
	
	OnAssetsDeletedHandle = FEditorDelegates::OnAssetsDeleted.AddLambda([](const TArray<UClass*>& Classes)
	{
		SceneOutlinerFolderUtils::OnWorldDeleted();
	});
}

void FColorOutlinerModule::RegisterOnMapChanged()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	
	OnMapChangedHandle = LevelEditorModule.OnMapChanged().AddLambda([&](UWorld* World, EMapChangeType MapChangeType)
	{
		FString NowMapPath;
		switch (MapChangeType)
		{
			using namespace SceneOutlinerFolderUtils;
			
			case EMapChangeType::LoadMap:
				/*Template or existing*/
				NowMapPath = World->GetPathName();
				if(NowMapPath.StartsWith(TEXT("/Temp"),ESearchCase::CaseSensitive))
				{
					SetIsTempMap(true);
				}
				else
				{
					SetIsTempMap(false);
					NowMapPath.RemoveFromEnd(TEXT(".")+World->GetMapName());
					OLSetMapPath(NowMapPath);
				}
			break;
		
			case EMapChangeType::NewMap:
				/*Empty level*/
				SetIsTempMap(true);
			break;
		
			case EMapChangeType::SaveMap:
				/*Is template or empty level to save?*/
				if(GetIsTempMap())
				{
					TempToSave(World);
				}
			break;
		
			case EMapChangeType::TearDownWorld:
				/*Clear cache*/
				OLSetMapPath(FString());
				ClearFolderColorsTemp();
			break;
		}
	});
}

void FColorOutlinerModule::RegisterOnFolderOperate()
{
	using namespace SceneOutlinerFolderUtils;
	
	OnFolderMovedHandle = FActorFolders::OnFolderMoved.AddLambda([](UWorld& World, const FFolder& Source, const FFolder& Dest)
	{
		SetIsFolderMoved(true);
		GetIsTempMap() ? UpdateFullPathTemp(Source,Dest) : UpdateFullPath(Source,Dest);
	});
	
	OnFolderDeletedHandle = FActorFolders::OnFolderDeleted.AddLambda([]( UWorld& World, const FFolder& DeletedFolder )
	{
		if(!GetIsFolderMoved())
		{
			/*Not move,means delete*/
			GetIsTempMap() ? DeleteFullPathTemp(DeletedFolder) : DeleteFullPath(DeletedFolder);
		}
		else
		{
			SetIsFolderMoved(false);
		}
	});
}

void FColorOutlinerModule::RegisterOutlinerItemLabelColumn()
{
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(TEXT("SceneOutliner"));
	SceneOutlinerModule.UnRegisterColumnType<FSceneOutlinerItemLabelColumn>();
	
	SceneOutlinerModule.RegisterDefaultColumnType<FSOItemLabelColumnReplace>(FSceneOutlinerColumnInfo(ESceneOutlinerColumnVisibility::Visible, 6));
}

void FColorOutlinerModule::RegisterOutlinerContextMenuExtend()
{
	UToolMenu* Menu = UToolMenus::Get()->ExtendMenu(SceneOutlinerFolderUtils::GetDefaultContextBaseMenuName());
	
	Menu->AddDynamicSection("SetFolderColorSection", FNewToolMenuDelegate::CreateLambda([this](UToolMenu* InMenu)
	{
		USceneOutlinerMenuContext* Context = InMenu->FindContext<USceneOutlinerMenuContext>();
		if (!Context)
		{
			return;
		}
		FToolMenuSection& Section = InMenu->FindOrAddSection("SceneOutlinerFolderOptions");
		Section.Label = LOCTEXT("FolderOptionsLabel", "Folder Options");
		
		SelectedSceneOutliner = Context->SceneOutliner;

		/*select and only select folder*/
		if (Context->NumSelectedItems > 0 && Context->NumSelectedFolders == Context->NumSelectedItems)
        {
			ExecuteFolderItems = SelectedSceneOutliner.Pin()->GetSelectedItems();
			
			Section.AddMenuEntry(
				"OutlinerSetColor",
				LOCTEXT("OutlinerSetColor", "Set Color"),
				LOCTEXT("OutlinerSetColorTooltip", "Sets the color this folder should appear as."),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Color"),
				FUIAction( FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerExecutePickColor ) )
				);
        }
		else
		{
			ExecuteFolderItems.Empty();
		}
	}));
}

void FColorOutlinerModule::OutlinerExecutePickColor()
{
	// Spawn a color picker, so the user can select which color they want
	FLinearColor InitialColor = SceneOutlinerFolderUtils::GetOutlinerFolderDefaultColor();
	
	// Make sure an color entry exists for all the paths, otherwise they won't update in realtime with the widget color
	for (const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteFolderItems)
	{
		if(FActorFolderTreeItem* SelectedFolder = SelectedItem->CastTo<FActorFolderTreeItem>())
		{
			const FString FullPath = SceneOutlinerFolderUtils::GetFolderFullPath(SelectedFolder);
            
			TOptional<FLinearColor> Color = SceneOutlinerFolderUtils::GetFolderColor(FullPath);
			if (Color.IsSet())
			{
				// Default the color to the first valid entry
				InitialColor = Color.GetValue();
				break;
			}
		}
	}

	FColorPickerArgs PickerArgs = FColorPickerArgs(InitialColor, FOnLinearColorValueChanged::CreateRaw(this, &FColorOutlinerModule::OnLinearColorValueChanged));
	PickerArgs.bIsModal = false;
	//PickerArgs.ParentWidget = ParentContent.Pin();

	OpenColorPicker(PickerArgs);
}

void FColorOutlinerModule::OnLinearColorValueChanged(const FLinearColor InColor)
{
	OnColorClicked(InColor);
}

FReply FColorOutlinerModule::OnColorClicked(const FLinearColor InColor)
{
	const STreeView<FSceneOutlinerTreeItemPtr>& TreeView = SelectedSceneOutliner.Pin()->GetTree();
	
	for(const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteFolderItems)
	{
		if(TSharedPtr<ITableRow> RowWidget = TreeView.WidgetFromItem(SelectedItem))
		{
			if(TSharedPtr<SSceneOutlinerTreeRow> FolderTreeRow = StaticCastSharedPtr<SSceneOutlinerTreeRow>(RowWidget))
			{
				/*Set color now*/
				SetRowItemColor(FolderTreeRow,InColor);
			}
		}
		
		if(FActorFolderTreeItem* SelectedFolder = SelectedItem->CastTo<FActorFolderTreeItem>())
		{
			if(!SceneOutlinerFolderUtils::GetIsTempMap())
			{
				/*Save folder color in ini*/
				FString FullPath = SceneOutlinerFolderUtils::GetFolderFullPath(SelectedFolder);
                SceneOutlinerFolderUtils::SaveFolderColors(FullPath,InColor);
			}
			else
			{
				SceneOutlinerFolderUtils::SaveFolderColorsTemp(SelectedFolder->GetPath().ToString(),InColor);
			}
		}
	}
	return FReply::Handled();
}

void FColorOutlinerModule::SetRowItemColor(TSharedPtr<SSceneOutlinerTreeRow> InRow, const FLinearColor InColor)
{
	if(!InRow) return;
				
	if(HackSMultiColumnTableRow* MultiColumnTableRow = (HackSMultiColumnTableRow*)InRow.Get())
	{
		if(const TSharedRef<SWidget>* ColumnWidget = MultiColumnTableRow->HackGetWidgetFromColumnId(FSceneOutlinerBuiltInColumnTypes::Label()))
		{
			TSharedPtr<SWidget> CurrentWidget;
			if(ColumnWidget->Get().GetChildren()->Num() == 0 ) return;
			CurrentWidget = ColumnWidget->Get().GetChildren()->GetChildAt(0);
						
			if(CurrentWidget->GetChildren()->Num() <= 1) return;
			/*SActorFolderTreeLabel*/
			CurrentWidget = CurrentWidget->GetChildren()->GetChildAt(1);

			SceneOutlinerFolderUtils::SetRowWidgetColor(CurrentWidget,InColor);
		}
	}
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FColorOutlinerModule, ColorOutliner)